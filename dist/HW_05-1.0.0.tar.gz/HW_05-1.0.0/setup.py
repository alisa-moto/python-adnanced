from setuptools import setup

setup(
    name='HW_05',
    version='1.0.0',
    description='A library package with 3 classes Library, Book, Reader for student work',
    author='Alisa Motorkina',
    author_email='lisa.motorkina@gmail.com',
    packages=['HW_05', 'HW_05.utils']
)
